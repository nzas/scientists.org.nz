/* $Id: README.txt,v 1.1 2009/06/04 15:14:36 mdekkers Exp $ */

Profile tokens

The module provides tokens for user object with profile fields

To install, place the entire module folder into your modules directory.
Go to Administer -> Site Building -> Modules and enable the Profile Tokens module.
